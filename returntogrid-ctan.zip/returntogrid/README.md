#returntogrid — A package to return some text to a grid
Packageversion: 0.1 
Packagedate: 2018/08/20
Author: Ulrike Fischer

## License
The returntogrid package may be modified and distributed under the terms and conditions of the 
[LaTeX Project Public License](https://www.latex-project.org/lppl/), version 1.3c or greater.


## Contents

- Readme (this file)
- returntogrid.sty (the sty)
- returntogrid.tex, returntogrid.pdf(the docu)

## Installation

Put the style where it can be found.


## Issues, comments, etc

https://github.com/u-fischer/returntogrid
